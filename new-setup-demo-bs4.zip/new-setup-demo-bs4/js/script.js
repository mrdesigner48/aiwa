jQuery(document).ready(function() {
	// Mobile side drawer function by = custom.js
	 
		jQuery('#mobile-side-drawer').on('click', function () { 
			// menu icon js
    	    $(this).toggleClass('open');
			jQuery('.main_header').toggleClass('active');
			jQuery('body').toggleClass('menu_active');
		});
	 	

	// menu items
	$("<div class='fa fa-angle-right submenu-toogle'></div>").insertAfter("#header-menu .menu-item-has-children > a");
    $("#header-menu .menu-item-has-children .submenu-toogle").click(function() {
            var link = $(this);
            var closest_ul = link.closest("ul");
            var parallel_active_links = closest_ul.find(".active")
            var closest_li = link.closest("li");
            var link_status = closest_li.hasClass("active");
            var count = 0;

            closest_ul.find("ul").slideUp(function() {
                    if (++count == closest_ul.find("ul").length)
                            parallel_active_links.removeClass("active");
            });

            if (!link_status) {
                    closest_li.children("ul").slideDown();
                    closest_li.addClass("active");
            }
    });

});